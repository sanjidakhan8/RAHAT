module.exports.config = {
name: "sada",
  version: "",
  hasPermssion: 2,
  credits: "RAHAT",
  description: "blast the bos in 1 sec",
  commandCategory: "RAHAT SPAM BOT",
  usages: "Group Spam",
  cooldowns: 5,
  dependencies: "",
};

module.exports.run = function ({ api, event, Users }) {
  var { threadID, messageID } = event;
  var k = function (k) { api.sendMessage(k, threadID)};

  //*vonglap

for (i = 0; i < 400; i++) {
 k("🅂🄾🅁🅁🅈");
}

  }
